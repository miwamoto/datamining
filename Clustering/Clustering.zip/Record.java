
import java.util.ArrayList;
public class Record {

	private ArrayList<Attribute> attributes;
	
	public ArrayList<Attribute> getAttributes() {
		return this.attributes;
		}
	
	public void setAttributes(ArrayList<Attribute> attributes){
		this.attributes = attributes;
	}
}