// This project was completed by Mona Iwamoto and Melissa Mendoza, without consulting code
// from other students.

import java.util.ArrayList;
public class Record {

	private ArrayList<Attribute> attributes;
	
	public ArrayList<Attribute> getAttributes() {
		return this.attributes;
		}
	
	public void setAttributes(ArrayList<Attribute> attributes){
		this.attributes = attributes;
	}
}